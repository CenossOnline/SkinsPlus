package com.skinsplus.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** The draw primitives the settings window is built from. */
public final class Ui {
	private Ui() {
	}

	public static int withAlpha(int argb, float alpha) {
		int a = Math.round(255f * Math.max(0f, Math.min(1f, alpha)));
		return (a << 24) | (argb & 0x00FFFFFF);
	}

	public static int mulAlpha(int argb, float multiplier) {
		int a = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, multiplier)));
		return (a << 24) | (argb & 0x00FFFFFF);
	}

	public static int mix(int from, int to, float t) {
		float f = Math.max(0f, Math.min(1f, t));
		int a = Math.round(((from >>> 24) & 0xFF) * (1f - f) + ((to >>> 24) & 0xFF) * f);
		int r = Math.round(((from >> 16) & 0xFF) * (1f - f) + ((to >> 16) & 0xFF) * f);
		int g = Math.round(((from >> 8) & 0xFF) * (1f - f) + ((to >> 8) & 0xFF) * f);
		int b = Math.round((from & 0xFF) * (1f - f) + (to & 0xFF) * f);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	public static void rect(GuiGraphicsExtractor graphics, int x, int y, int width, int height, int color) {
		if (width <= 0 || height <= 0) return;
		graphics.fill(x, y, x + width, y + height, color);
	}

	public static void rounded(GuiGraphicsExtractor graphics, int x, int y, int width, int height, int radius, int color) {
		if (width <= 0 || height <= 0) return;
		int r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
		if (r == 0) {
			rect(graphics, x, y, width, height, color);
			return;
		}
		for (int row = 0; row < height; row++) {
			int inset;
			if (row < r) {
				inset = cornerInset(r, row);
			} else if (row >= height - r) {
				inset = cornerInset(r, height - 1 - row);
			} else {
				inset = 0;
			}
			graphics.fill(x + inset, y + row, x + width - inset, y + row + 1, color);
		}
	}

	private static int cornerInset(int radius, int row) {
		double dy = radius - row - 0.5;
		return (int) Math.round(radius - Math.sqrt(Math.max(0.0, (double) radius * radius - dy * dy)));
	}

	/** Border ring drawn inside the bounds, so controls keep their exact size. */
	public static void borderRing(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
			int radius, int thickness, int color) {
		if (width <= 0 || height <= 0 || thickness <= 0) return;
		int t = Math.max(1, Math.min(thickness, Math.min(width, height) / 2));
		int r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
		if (r == 0) {
			rect(graphics, x, y, width, t, color);
			rect(graphics, x, y + height - t, width, t, color);
			rect(graphics, x, y + t, t, height - t * 2, color);
			rect(graphics, x + width - t, y + t, t, height - t * 2, color);
			return;
		}
		rect(graphics, x + r, y, width - r * 2, t, color);
		rect(graphics, x + r, y + height - t, width - r * 2, t, color);
		rect(graphics, x, y + r, t, height - r * 2, color);
		rect(graphics, x + width - t, y + r, t, height - r * 2, color);
		for (int row = 0; row < r && row < height; row++) {
			int inset = cornerInset(r, row);
			int left = x + inset;
			int right = left + width - inset * 2 - t;
			if (right < left) continue;
			rect(graphics, left, y + row, t, 1, color);
			rect(graphics, right, y + row, t, 1, color);
			rect(graphics, left, y + height - 1 - row, t, 1, color);
			rect(graphics, right, y + height - 1 - row, t, 1, color);
		}
	}

	public static void roundedBorder(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
			int radius, int border, int fill) {
		rounded(graphics, x, y, width, height, radius, fill);
		borderRing(graphics, x, y, width, height, radius, 1, border);
	}

	public static void shadow(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
			int radius, int color, int spread) {
		if (spread <= 0) return;
		int layers = Math.min(4, spread);
		for (int i = layers; i >= 1; i--) {
			int offset = Math.round((float) spread * i / layers);
			int alpha = Math.round(((color >>> 24) & 0xFF) * (1f - (float) i / (layers + 1)) * 0.7f);
			if (alpha <= 2) continue;
			rounded(graphics, x - offset, y - offset + 1, width + offset * 2, height + offset * 2,
					radius + offset, withAlpha(color, alpha / 255f));
		}
	}

	public static void separator(GuiGraphicsExtractor graphics, int x, int y, int width, int color) {
		graphics.fill(x, y, x + width, y + 1, color);
	}

	public static void text(GuiGraphicsExtractor graphics, Font font, String text, int x, int y, int color) {
		graphics.text(font, text, x, y, color, true);
	}

	public static void textNoShadow(GuiGraphicsExtractor graphics, Font font, String text, int x, int y, int color) {
		graphics.text(font, text, x, y, color);
	}

	public static void textRight(GuiGraphicsExtractor graphics, Font font, String text, int right, int y, int color) {
		text(graphics, font, text, right - font.width(text), y, color);
	}

	public static void textCentered(GuiGraphicsExtractor graphics, Font font, String text, int left, int width,
			int y, int color) {
		text(graphics, font, text, left + (width - font.width(text)) / 2, y, color);
	}

	public static void textCenteredNoShadow(GuiGraphicsExtractor graphics, Font font, String text, int left,
			int width, int y, int color) {
		textNoShadow(graphics, font, text, left + (width - font.width(text)) / 2, y, color);
	}

	/** Text cut to {@code width}, with an ellipsis when there is room for one. */
	public static void textClipped(GuiGraphicsExtractor graphics, Font font, String text, int x, int y,
			int width, int color) {
		if (text == null || text.isEmpty() || width <= 0) return;
		if (font.width(text) <= width) {
			text(graphics, font, text, x, y, color);
			return;
		}
		String ellipsis = "...";
		int available = width - font.width(ellipsis);
		if (available <= 0) return;
		int end = text.length();
		while (end > 0 && font.width(text.substring(0, end)) > available) end--;
		text(graphics, font, text.substring(0, end) + ellipsis, x, y, color);
	}
}
