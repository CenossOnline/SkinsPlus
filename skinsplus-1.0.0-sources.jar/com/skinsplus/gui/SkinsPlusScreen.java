package com.skinsplus.gui;

import com.skinsplus.Config;
import com.skinsplus.SkinsPlus;
import com.skinsplus.SkinsPlus.Animation;
import com.skinsplus.SkinsPlus.Part;
import com.skinsplus.SkinsPlus.Trigger;
import com.skinsplus.SkinsPlusClient;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

/**
 * Skins+ settings, laid out as Veyl's floating settings windows: a global window plus one
 * draggable sub-window per event.
 */
public final class SkinsPlusScreen extends Screen {
	private static final int HEADER = 14;
	private static final int SEARCH_BAND = 15;
	private static final int SEARCH_HEIGHT = 12;
	private static final int ROW_GAP = 2;
	private static final int BUTTON_HEIGHT = 12;
	private static final int BUTTON_GAP = 3;
	private static final int SCROLLBAR_GUTTER = 6;
	private static final int SCROLLBAR_GRAB = 4;
	private static final int WINDOW_WIDTH = 260;
	private static final int CORNER = 3;

	private static final int ACCENT = 0xFFE45C97;
	private static final int TEXT = 0xFFFFFFFF;
	private static final int TEXT_SECONDARY = 0xFFFFFFFF;
	private static final int TEXT_DISABLED = 0xFFFFFFFF;
	private static final int TEXT_ON_ACCENT = 0xFFFFFFFF;
	private static final int BORDER = 0xFF3A3244;
	private static final int SEPARATOR = 0xFF272130;
	private static final int HOVER = 0x992C2634;
	private static final int WINDOW = 0x8017141B;
	private static final int HEADER_FILL = 0xA81E1A22;
	private static final int MODULE_BACKGROUND = 0x5A151016;
	private static final int DROPDOWN = 0x8A241F2B;
	private static final int POPUP = 0x9618141C;
	private static final int SEARCH_BAR = 0x881B171F;
	private static final int CHECKBOX_OFF = 0x8A322B38;
	private static final int SLIDER_TRACK = 0xAA2E2733;
	private static final int SCROLLBAR = 0xCC3E3549;
	private static final int DANGER = 0xFFE45C5C;
	private static final int SHADOW = 0x66000000;

	private static final String RESET_LABEL = "Reset Skins+";
	private static final String CLOSE_LABEL = "Close";
	private static final String EVENT_RESET_LABEL = "Reset event";
	private static final String EVENT_BACK_LABEL = "Back";
	private static final long RESET_ARM_MS = 3000L;
	private static final int POPUP_ROW = 13;
	private static final int POPUP_TITLE = 12;
	private static final int POPUP_SEARCH = 15;
	private static final int POPUP_FOOTER = 15;
	private static final int MAX_POPUP_ROWS = 10;

	private final Window main = new Window("Skins+", null);
	private Window event;
	private Row slidingRow;
	private int rangeHandle;
	private boolean draggingScrollbar;
	private Window scrollbarWindow;
	private int scrollbarGrab;
	private Window draggingWindow;

	public SkinsPlusScreen() {
		super(Component.literal("Skins+"));
	}

	private static Config config() {
		return Config.get();
	}

	@Override
	protected void init() {
		buildMainRows();
		main.x = config().windowX >= 0 ? config().windowX : (width - WINDOW_WIDTH) / 2;
		main.y = config().windowY >= 0 ? config().windowY : (height - frameHeight(main)) / 2;
		main.scroll = Math.max(0, config().windowScroll);
		clampWindow(main);
		clampScroll(main);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	// ---------------------------------------------------------------- rows

	private void buildMainRows() {
		List<Row> rows = main.rows;
		rows.clear();

		rows.add(booleanRow("Enabled", "Master switch for the outer-layer flicker",
				() -> config().enabled, SkinsPlus.get()::setEnabled));

		rows.add(enumRow("Animation", "Set every event to one animation; sub-windows can still change them",
				() -> {
					Animation common = config().commonAnimation();
					return common == null ? "Mixed" : common.label();
				}, this::globalAnimationOptions));

		rows.add(numberRow("Speed", "Default switches per second for events that follow it",
				() -> config().speed, value -> config().speed = value,
				0.5, 20.0, 0.5, " /s", 1));
		rows.add(numberRow("Duty cycle", "Default share of each cycle the layer is visible",
				() -> config().duty, value -> config().duty = value,
				5.0, 95.0, 5.0, "%", 0));

		rows.add(booleanRow("Random bursts", "Fire a set number of times per window instead of continuously",
				() -> config().bursts, value -> {
					config().bursts = value;
					SkinsPlus.get().settingsChanged();
				}));
		Row burstCount = numberRow("Fire count", "How many flashes each window contains (default 6)",
				() -> config().burstCount, value -> config().burstCount = (int) Math.round(value),
				1.0, 30.0, 1.0, "x", 0);
		burstCount.visible = () -> config().bursts;
		rows.add(burstCount);
		Row burstWindow = numberRow("Time window", "How long one burst schedule lasts (default 60 s)",
				() -> config().burstWindow, value -> config().burstWindow = value,
				5.0, 300.0, 5.0, " s", 0);
		burstWindow.visible = () -> config().bursts;
		rows.add(burstWindow);
		Row burstLength = numberRow("Burst length", "How long each individual flash lasts",
				() -> config().burstLength, value -> config().burstLength = value,
				0.1, 5.0, 0.1, " s", 1);
		burstLength.visible = () -> config().bursts;
		rows.add(burstLength);

		Row interval = rangeRow("Random rate", "Shortest and longest hold between flips",
				() -> config().intervalMin, () -> config().intervalMax,
				(low, high) -> {
					config().intervalMin = low;
					config().intervalMax = high;
				}, 0.5, 20.0, 0.5, " /s", 1);
		interval.visible = () -> config().usesAnimation(Animation.RANDOM);
		rows.add(interval);

		Row run = rangeRow("Pattern length", "How long each random pattern is played",
				() -> config().chaosRunMin, () -> config().chaosRunMax,
				(low, high) -> {
					config().chaosRunMin = low;
					config().chaosRunMax = high;
				}, 0.5, 15.0, 0.5, " s", 1);
		run.visible = () -> config().usesAnimation(Animation.CHAOS);
		rows.add(run);

		Row rest = numberRow("Rest length", "Pause between random patterns",
				() -> config().chaosPause, value -> config().chaosPause = value,
				0.1, 5.0, 0.1, " s", 1);
		rest.visible = () -> config().usesAnimation(Animation.CHAOS);
		rows.add(rest);

		Row shuffle = numberRow("Switch every", "How many speed cycles each random pattern lasts",
				() -> config().shuffleEvery, value -> config().shuffleEvery = (int) Math.round(value),
				1.0, 16.0, 1.0, " cycles", 0);
		shuffle.visible = () -> config().usesAnimation(Animation.SHUFFLE);
		rows.add(shuffle);

		rows.add(multiRow("Parts", "Which outer-layer parts flicker",
				this::partsSummary, this::partOptions));

		rows.add(booleanRow("Visible to others", "Mirror model-part changes to the server",
				() -> config().visibleToOthers, value -> {
					config().visibleToOthers = value;
					SkinsPlus.get().valuesChanged();
				}));

		rows.add(headerRow("Events", "Per-event animations, opened with the gear button"));
		for (Trigger trigger : Trigger.values()) {
			rows.add(eventRow(trigger));
		}
	}

	private void buildEventRows(Window window, Trigger trigger) {
		List<Row> rows = window.rows;
		rows.clear();

		rows.add(booleanRow("Enabled", "Play this event's animation",
				() -> config().event(trigger).enabled, value -> {
					config().event(trigger).enabled = value;
					SkinsPlus.get().settingsChanged();
				}));

		rows.add(enumRow("Animation", "Pattern shown while this event is happening",
				() -> config().animation(trigger).label(), () -> eventAnimationOptions(trigger)));

		rows.add(booleanRow("Follow global speed", "Use the Speed slider from the main window",
				() -> config().event(trigger).speed == null, value -> {
					config().event(trigger).speed = value ? null : config().speed;
					SkinsPlus.get().settingsChanged();
				}));
		Row speed = numberRow("Speed", "Switches per second for this event only",
				() -> config().speedFor(trigger), value -> config().event(trigger).speed = value,
				0.5, 20.0, 0.5, " /s", 1);
		speed.visible = () -> config().event(trigger).speed != null;
		rows.add(speed);

		rows.add(booleanRow("Follow global duty", "Use the Duty cycle slider from the main window",
				() -> config().event(trigger).duty == null, value -> {
					config().event(trigger).duty = value ? null : config().duty;
					SkinsPlus.get().settingsChanged();
				}));
		Row duty = numberRow("Duty cycle", "Share of each cycle this event is visible",
				() -> config().dutyFor(trigger), value -> config().event(trigger).duty = value,
				5.0, 95.0, 5.0, "%", 0);
		duty.visible = () -> config().event(trigger).duty != null;
		rows.add(duty);

		if (trigger == Trigger.LOW_HEALTH) {
			rows.add(numberRow("Health threshold", "Health at which this event starts playing",
					() -> config().healthThreshold, value -> config().healthThreshold = value,
					1.0, 20.0, 0.5, " hp", 1));
		}
		if (trigger == Trigger.NEARBY) {
			rows.add(numberRow("Trigger radius", "How close another player must be",
					() -> config().triggerRadius, value -> config().triggerRadius = value,
					2.0, 64.0, 2.0, " blocks", 0));
		}
	}

	private Row booleanRow(String label, String description, BooleanSupplier get, Consumer<Boolean> set) {
		Row row = new Row(Kind.BOOLEAN, label, description, 14);
		row.boolGet = get;
		row.boolSet = set;
		return row;
	}

	private Row enumRow(String label, String description, Supplier<String> value,
			Supplier<List<Option>> options) {
		Row row = new Row(Kind.ENUM, label, description, 14);
		row.enumText = value;
		row.options = options;
		return row;
	}

	private Row multiRow(String label, String description, Supplier<String> summary,
			Supplier<List<Option>> options) {
		Row row = new Row(Kind.MULTI, label, description, 14);
		row.multiText = summary;
		row.options = options;
		return row;
	}

	private Row numberRow(String label, String description, DoubleSupplier get, DoubleConsumer set,
			double min, double max, double step, String suffix, int decimals) {
		Row row = new Row(Kind.NUMBER, label, description, 24);
		row.numberGet = get;
		row.numberSet = set;
		row.min = min;
		row.max = max;
		row.step = step;
		row.suffix = suffix;
		row.decimals = decimals;
		return row;
	}

	private Row rangeRow(String label, String description, DoubleSupplier low, DoubleSupplier high,
			BiConsumer<Double, Double> set, double min, double max, double step, String suffix, int decimals) {
		Row row = new Row(Kind.RANGE, label, description, 26);
		row.numberGet = low;
		row.rangeHigh = high;
		row.rangeSet = set;
		row.min = min;
		row.max = max;
		row.step = step;
		row.suffix = suffix;
		row.decimals = decimals;
		return row;
	}

	private Row eventRow(Trigger trigger) {
		Row row = new Row(Kind.EVENT, trigger.label(),
				"Animation and per-event overrides for " + trigger.label().toLowerCase(Locale.ROOT), 14);
		row.trigger = trigger;
		return row;
	}

	private Row headerRow(String label, String description) {
		return new Row(Kind.HEADER, label, description, 18);
	}

	private List<Option> globalAnimationOptions() {
		List<Option> options = new ArrayList<>();
		for (Animation animation : Animation.values()) {
			options.add(new Option(animation.label(), () -> config().commonAnimation() == animation,
					() -> {
						config().setAllAnimations(animation);
						SkinsPlus.get().settingsChanged();
					}));
		}
		return options;
	}

	private List<Option> eventAnimationOptions(Trigger trigger) {
		List<Option> options = new ArrayList<>();
		for (Animation animation : Animation.values()) {
			options.add(new Option(animation.label(), () -> config().animation(trigger) == animation,
					() -> selectAnimation(trigger, animation)));
		}
		return options;
	}

	private static void selectAnimation(Trigger trigger, Animation animation) {
		config().event(trigger).animation = animation.name();
		SkinsPlus.get().settingsChanged();
	}

	private List<Option> partOptions() {
		List<Option> options = new ArrayList<>();
		for (Part part : Part.values()) {
			options.add(new Option(part.label(), () -> config().parts.contains(part.name()), () -> {
				toggleIn(config().parts, part.name());
				SkinsPlus.get().valuesChanged();
			}));
		}
		return options;
	}

	private String partsSummary() {
		return selectionSummary(config().parts);
	}

	private static String selectionSummary(Set<String> selected) {
		return selected.isEmpty() ? "none" : selected.size() + " on";
	}

	private static void toggleIn(Set<String> set, String value) {
		if (!set.remove(value)) set.add(value);
	}

	// ---------------------------------------------------------------- geometry

	private List<Row> visibleRows(Window window) {
		List<Row> out = new ArrayList<>();
		String needle = window.query.trim().toLowerCase(Locale.ROOT);
		for (Row row : window.rows) {
			if (!row.visible.getAsBoolean()) continue;
			if (!needle.isEmpty()) {
				if (row.kind == Kind.HEADER) continue;
				if (!row.label.toLowerCase(Locale.ROOT).contains(needle)
						&& !row.description.toLowerCase(Locale.ROOT).contains(needle)) {
					continue;
				}
			}
			out.add(row);
		}
		return out;
	}

	private int bodyHeight(Window window) {
		int total = 0;
		for (Row row : visibleRows(window)) total += row.height + ROW_GAP;
		return Math.max(20, total + 16);
	}

	private int footerHeight() {
		return 2 + BUTTON_HEIGHT + 2 + 1;
	}

	private int frameHeight(Window window) {
		int content = HEADER + SEARCH_BAND + bodyHeight(window) + footerHeight() + 2;
		int floor = HEADER + SEARCH_BAND + 40 + footerHeight() + 2;
		int maximum = Math.max(floor, height - 8);
		return Math.max(floor, Math.min(content, maximum));
	}

	private int bodyViewport(Window window) {
		return Math.max(12, frameHeight(window) - HEADER - SEARCH_BAND - footerHeight() - 2);
	}

	private int maxScroll(Window window) {
		return Math.max(0, bodyHeight(window) - bodyViewport(window));
	}

	private int bodyTop(Window window) {
		return window.y + HEADER + SEARCH_BAND;
	}

	private int footerY(Window window) {
		return window.y + frameHeight(window) - footerHeight() + 1;
	}

	private void layoutRows(Window window) {
		if (window == null) return;
		int gutter = maxScroll(window) > 0 ? SCROLLBAR_GUTTER : 0;
		int cursor = bodyTop(window) - window.scroll;
		for (Row row : visibleRows(window)) {
			row.x = window.x + 4;
			row.y = cursor;
			row.w = WINDOW_WIDTH - 12 - gutter;
			cursor += row.height + ROW_GAP;
		}
	}

	private void clampWindow(Window window) {
		if (window == null || window.dragging) return;
		int margin = 8;
		int maxX = Math.max(margin, width - WINDOW_WIDTH - margin);
		int maxY = Math.max(margin, height - frameHeight(window) - margin);
		window.x = Math.max(margin, Math.min(window.x, maxX));
		window.y = Math.max(margin, Math.min(window.y, maxY));
	}

	private void clampScroll(Window window) {
		if (window == null) return;
		window.scroll = Math.max(0, Math.min(window.scroll, maxScroll(window)));
	}

	private Bounds searchBounds(Window window) {
		return new Bounds(window.x + 4, window.y + HEADER + 2, WINDOW_WIDTH - 8, SEARCH_HEIGHT);
	}

	private Bounds closeBounds(Window window) {
		return new Bounds(window.x + WINDOW_WIDTH - 14, window.y, 12, HEADER);
	}

	private Bounds booleanControl(Row row) {
		return new Bounds(row.x + row.w - 15, row.y + 2, 13, 11);
	}

	private Bounds enumControl(Row row) {
		return new Bounds(row.x + row.w - 88, row.y + 2, 86, 11);
	}

	private Bounds multiControl(Row row) {
		return new Bounds(row.x + row.w - 64, row.y + 2, 62, 11);
	}

	private Bounds gearBounds(Row row) {
		return new Bounds(row.x + row.w - 13, row.y, 13, 14);
	}

	private Bounds eventCheckbox(Row row) {
		return new Bounds(row.x + row.w - 32, row.y + 2, 13, 11);
	}

	private Bounds numberTrack(Row row) {
		return new Bounds(row.x + 1, row.y + 14, row.w - 4, 7);
	}

	private Bounds rangeTrack(Row row) {
		return new Bounds(row.x + 1, row.y + 15, row.w - 4, 7);
	}

	private Bounds footerBounds(Window window, int index) {
		int widest = 0;
		for (int i = 0; i < 2; i++) widest = Math.max(widest, font.width(footerLabel(window, i, false)) + 8);
		int columns = Math.max(1, Math.min(2, (WINDOW_WIDTH - 8) / Math.max(1, widest + BUTTON_GAP)));
		int row = index / columns;
		int column = index % columns;
		int x = window.x + 4 + column * (widest + BUTTON_GAP);
		int y = footerY(window) + 2 + row * (BUTTON_HEIGHT + 2);
		int w = Math.min(widest, Math.max(20, window.x + WINDOW_WIDTH - 3 - x));
		return new Bounds(x, y, w, BUTTON_HEIGHT);
	}

	private String footerLabel(Window window, int index, boolean armed) {
		if (index == 0) {
			return armed ? "Confirm?" : (window.trigger == null ? RESET_LABEL : EVENT_RESET_LABEL);
		}
		return window.trigger == null ? CLOSE_LABEL : EVENT_BACK_LABEL;
	}

	private Bounds scrollbarTrack(Window window) {
		int viewport = Math.max(1, bodyViewport(window));
		return new Bounds(window.x + WINDOW_WIDTH - SCROLLBAR_GUTTER + 1, bodyTop(window), 3, viewport);
	}

	private int[] scrollbarThumb(Window window) {
		int total = bodyHeight(window);
		int view = bodyViewport(window);
		if (total <= view + 1) return null;
		Bounds track = scrollbarTrack(window);
		int height = Math.max(10, track.h * view / Math.max(1, total));
		int max = Math.max(1, total - view);
		int top = track.y + Math.round((float) Math.max(0, Math.min(window.scroll, max)) / max * (track.h - height));
		return new int[]{top, height};
	}

	private Window windowAt(double mouseX, double mouseY) {
		if (event != null && containsWindow(event, mouseX, mouseY)) return event;
		if (containsWindow(main, mouseX, mouseY)) return main;
		return null;
	}

	private boolean containsWindow(Window window, double mouseX, double mouseY) {
		return window != null
				&& mouseX >= window.x && mouseX <= window.x + WINDOW_WIDTH
				&& mouseY >= window.y && mouseY <= window.y + frameHeight(window);
	}

	// ---------------------------------------------------------------- rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		clampWindow(main);
		clampWindow(event);
		clampScroll(main);
		clampScroll(event);
		layoutRows(main);
		layoutRows(event);

		Ui.rect(graphics, 0, 0, width, height, 0x5A000000);

		drawWindow(graphics, main, mouseX, mouseY);
		if (event != null) drawWindow(graphics, event, mouseX, mouseY);

		Window owner = popupWindow();
		if (owner != null) drawPopup(graphics, owner, mouseX, mouseY);
	}

	private void drawWindow(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		int x = window.x;
		int y = window.y;
		int h = frameHeight(window);

		Ui.shadow(graphics, x, y, WINDOW_WIDTH, h, CORNER, SHADOW, 5);
		Ui.roundedBorder(graphics, x, y, WINDOW_WIDTH, h, CORNER, BORDER, WINDOW);
		Ui.rounded(graphics, x + 1, y + 1, WINDOW_WIDTH - 2, HEADER - 1, CORNER - 1, HEADER_FILL);
		Ui.separator(graphics, x + 1, y + HEADER - 1, WINDOW_WIDTH - 2, Ui.withAlpha(ACCENT, 0.55f));

		drawHeader(graphics, window, mouseX, mouseY);
		drawSearch(graphics, window, mouseX, mouseY);

		int gutter = maxScroll(window) > 0 ? SCROLLBAR_GUTTER : 0;
		int top = bodyTop(window);
		graphics.enableScissor(x + 1, top, x + WINDOW_WIDTH - 1 - gutter, top + bodyViewport(window));
		List<Row> visible = visibleRows(window);
		for (Row row : visible) {
			if (row.y + row.height < top || row.y > top + bodyViewport(window)) continue;
			drawRow(graphics, row, mouseX, mouseY);
		}
		if (visible.isEmpty()) {
			Ui.text(graphics, font, "No settings match.", x + 8, top + 6, TEXT_DISABLED);
		}
		graphics.disableScissor();

		drawScrollbar(graphics, window, mouseX, mouseY);
		drawFooter(graphics, window, mouseX, mouseY);
	}

	private void drawHeader(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		int x = window.x;
		int y = window.y;

		int right = x + WINDOW_WIDTH - 14;
		int titleRight = right;
		if (window.trigger == null) {
			String key = SkinsPlusClient.toggleKeyLabel();
			String keyText = key.isEmpty() ? "" : "[" + key + "]";
			if (!keyText.isEmpty()) {
				int keyLeft = right - font.width(keyText);
				Ui.text(graphics, font, keyText, keyLeft, y + 3, TEXT_SECONDARY);
				titleRight = keyLeft - 5;
			}
		}
		Ui.textClipped(graphics, font, window.title, x + 6, y + 3,
				Math.max(12, titleRight - (x + 6)), TEXT);

		boolean closeHover = closeBounds(window).has(mouseX, mouseY);
		Ui.text(graphics, font, "x", x + WINDOW_WIDTH - 11, y + 3, closeHover ? DANGER : TEXT_SECONDARY);
	}

	private void drawSearch(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		Bounds bounds = searchBounds(window);
		Ui.roundedBorder(graphics, bounds.x, bounds.y, bounds.w, bounds.h, 3,
				window.searching ? ACCENT : BORDER, SEARCH_BAR);

		if (window.query.isEmpty()) {
			Ui.text(graphics, font, "Search settings...", bounds.x + 5, bounds.y + 2, TEXT_DISABLED);
		} else {
			Ui.textClipped(graphics, font, window.query, bounds.x + 5, bounds.y + 2, bounds.w - 20, TEXT);
			if (window.searching && (System.currentTimeMillis() / 500L) % 2L == 0L) {
				int caretIndex = Math.max(0, Math.min(window.caret, window.query.length()));
				int caretX = bounds.x + 5 + font.width(window.query.substring(0, caretIndex));
				if (caretX < bounds.x + bounds.w - 4) {
					Ui.rect(graphics, caretX, bounds.y + 2, 1, 9, ACCENT);
				}
			}
			boolean clearHover = mouseX >= bounds.x + bounds.w - 12 && mouseX <= bounds.x + bounds.w - 2
					&& mouseY >= bounds.y && mouseY <= bounds.y + bounds.h;
			Ui.text(graphics, font, "x", bounds.x + bounds.w - 10, bounds.y + 2,
					clearHover ? TEXT : TEXT_DISABLED);
		}
	}

	private void drawRow(GuiGraphicsExtractor graphics, Row row, int mouseX, int mouseY) {
		if (row.kind == Kind.HEADER) {
			Ui.textNoShadow(graphics, font, row.label, row.x + 1, row.y + 5, TEXT_DISABLED);
			Ui.separator(graphics, row.x - 1, row.y + row.height - 2, row.w + 2, SEPARATOR);
			return;
		}

		boolean hovered = mouseX >= row.x && mouseX < row.x + row.w
				&& mouseY >= row.y && mouseY < row.y + row.height;
		if (hovered) {
			Ui.rounded(graphics, row.x - 1, row.y, row.w + 2, row.height, 2, Ui.withAlpha(HOVER, 0.35f));
		}

		int labelY = row.y + 3;

		switch (row.kind) {
			case BOOLEAN -> {
				Bounds control = booleanControl(row);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, control.x - (row.x + 1) - 4), TEXT);
				drawToggle(graphics, control, row.boolGet.getAsBoolean(), control.has(mouseX, mouseY));
			}
			case ENUM -> {
				Bounds control = enumControl(row);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, control.x - (row.x + 1) - 4), TEXT);
				boolean controlHover = control.has(mouseX, mouseY);
				Ui.roundedBorder(graphics, control.x, control.y, control.w, control.h, 3,
						controlHover ? ACCENT : BORDER,
						controlHover ? Ui.mix(DROPDOWN, HOVER, 0.5f) : DROPDOWN);
				Ui.textClipped(graphics, font, row.enumText.get(), control.x + 4, control.y + 2,
						control.w - 13, TEXT);
				Ui.text(graphics, font, "v", control.x + control.w - 8, control.y + 2, TEXT_SECONDARY);
			}
			case MULTI -> {
				Bounds control = multiControl(row);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, control.x - (row.x + 1) - 4), TEXT);
				boolean controlHover = control.has(mouseX, mouseY);
				Ui.roundedBorder(graphics, control.x, control.y, control.w, control.h, 3,
						controlHover ? ACCENT : BORDER,
						controlHover ? Ui.mix(DROPDOWN, HOVER, 0.5f) : DROPDOWN);
				Ui.textClipped(graphics, font, row.multiText.get(), control.x + 5, control.y + 2,
						control.w - 9, TEXT);
			}
			case NUMBER -> {
				String value = numberText(row);
				int valueWidth = font.width(value);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, row.w - valueWidth - 9), TEXT);
				Ui.text(graphics, font, value, row.x + row.w - 2 - valueWidth, labelY, TEXT);
				Bounds track = numberTrack(row);
				boolean trackHover = track.containsExpanded(mouseX, mouseY, 4);
				drawSlider(graphics, track, fraction(row.numberGet.getAsDouble(), row.min, row.max),
						trackHover || slidingRow == row);
			}
			case RANGE -> {
				String value = rangeText(row);
				int valueWidth = font.width(value);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, row.w - valueWidth - 9), TEXT);
				Ui.text(graphics, font, value, row.x + row.w - 2 - valueWidth, labelY, TEXT);
				drawRange(graphics, rangeTrack(row), row, mouseX, mouseY);
			}
			case EVENT -> {
				Config.EventSettings settings = config().event(row.trigger);
				boolean enabled = settings != null && settings.enabled;
				Bounds box = eventCheckbox(row);
				Bounds gear = gearBounds(row);
				Ui.textClipped(graphics, font, row.label, row.x + 1, labelY,
						Math.max(10, box.x - (row.x + 1) - 4), enabled ? TEXT : TEXT_DISABLED);
				drawToggle(graphics, new Bounds(box.x, box.y, 13, 11), enabled, box.has(mouseX, mouseY));
				drawGear(graphics, gear, gear.has(mouseX, mouseY));
			}
			default -> {
			}
		}
	}

	private void drawToggle(GuiGraphicsExtractor graphics, Bounds control, boolean on, boolean hovered) {
		int fill = on ? ACCENT : CHECKBOX_OFF;
		if (hovered) fill = Ui.mix(fill, 0xFFFFFFFF, 0.15f);
		int border = on ? Ui.mix(ACCENT, 0xFFFFFFFF, 0.35f) : BORDER;
		Ui.roundedBorder(graphics, control.x, control.y, control.w, control.h, 2, border, fill);
		if (on) {
			Ui.textCenteredNoShadow(graphics, font, "x", control.x, control.w, control.y + 2, TEXT_ON_ACCENT);
		}
	}

	/** A small gear: ring, four wide teeth and a hub. */
	private void drawGear(GuiGraphicsExtractor graphics, Bounds bounds, boolean hovered) {
		int color = hovered ? ACCENT : TEXT;
		int iconX = bounds.x + 1;
		int iconY = bounds.y + 2;
		Ui.borderRing(graphics, iconX + 2, iconY + 2, 7, 7, 3, 1, color);
		Ui.rect(graphics, iconX + 4, iconY, 3, 2, color);
		Ui.rect(graphics, iconX + 4, iconY + 9, 3, 2, color);
		Ui.rect(graphics, iconX, iconY + 4, 2, 3, color);
		Ui.rect(graphics, iconX + 9, iconY + 4, 2, 3, color);
		Ui.rect(graphics, iconX + 5, iconY + 5, 1, 1, color);
	}

	private void drawSlider(GuiGraphicsExtractor graphics, Bounds track, double progress, boolean hovered) {
		Ui.rounded(graphics, track.x, track.y, track.w, track.h, track.h / 2, SLIDER_TRACK);
		int filled = Math.round((float) (track.w * Math.max(0, Math.min(1, progress))));
		if (filled > 0) {
			Ui.rounded(graphics, track.x, track.y, Math.max(2, filled), track.h, track.h / 2, ACCENT);
		}
		int knobX = Math.max(track.x, Math.min(track.x + filled - 2, track.x + track.w - 3));
		Ui.rounded(graphics, knobX, track.y - 2, 4, track.h + 4, 2,
				hovered ? Ui.mix(ACCENT, 0xFFFFFFFF, 0.4f) : ACCENT);
	}

	private void drawRange(GuiGraphicsExtractor graphics, Bounds track, Row row, int mouseX, int mouseY) {
		Ui.rounded(graphics, track.x, track.y, track.w, track.h, track.h / 2, SLIDER_TRACK);
		double lowFraction = fraction(row.numberGet.getAsDouble(), row.min, row.max);
		double highFraction = fraction(row.rangeHigh.getAsDouble(), row.min, row.max);
		int lowX = track.x + Math.round((float) (track.w * lowFraction));
		int highX = track.x + Math.round((float) (track.w * highFraction));
		if (highX > lowX) {
			Ui.rounded(graphics, lowX, track.y, Math.max(2, highX - lowX), track.h, track.h / 2, ACCENT);
		}
		boolean hovered = track.containsExpanded(mouseX, mouseY, 4);
		int lowColor = hovered && slidingRow == row && rangeHandle == 0 ? 0xFFFFFFFF : ACCENT;
		int highColor = hovered && slidingRow == row && rangeHandle == 1 ? 0xFFFFFFFF : ACCENT;
		Ui.rounded(graphics, lowX - 1, track.y - 1, 3, track.h + 2, 1, lowColor);
		Ui.rounded(graphics, highX - 2, track.y - 1, 3, track.h + 2, 1, highColor);
	}

	private void drawScrollbar(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		int[] thumb = scrollbarThumb(window);
		if (thumb == null) return;
		Bounds track = scrollbarTrack(window);
		int radius = Math.max(1, track.w / 2);
		Ui.rounded(graphics, track.x, track.y, track.w, track.h, radius, Ui.withAlpha(BORDER, 0.30f));
		boolean hovered = mouseX >= track.x - SCROLLBAR_GRAB && mouseX <= track.x + track.w + SCROLLBAR_GRAB
				&& mouseY >= thumb[0] && mouseY <= thumb[0] + thumb[1];
		Ui.rounded(graphics, track.x, thumb[0], track.w, thumb[1], radius,
				hovered || draggingScrollbar && scrollbarWindow == window ? 0xFFFFFFFF : SCROLLBAR);
	}

	private void drawFooter(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		int y = footerY(window);
		Ui.separator(graphics, window.x + 1, y, WINDOW_WIDTH - 2, SEPARATOR);

		boolean armed = System.currentTimeMillis() < window.resetArmedUntil;
		for (int i = 0; i < 2; i++) {
			Bounds bounds = footerBounds(window, i);
			boolean hovered = bounds.has(mouseX, mouseY);
			boolean reset = i == 0;
			int fill = hovered ? HOVER : MODULE_BACKGROUND;
			int border = reset && armed ? DANGER : BORDER;
			Ui.roundedBorder(graphics, bounds.x, bounds.y, bounds.w, bounds.h, 3, border, fill);
			int color = TEXT;
			Ui.textClipped(graphics, font, footerLabel(window, i, reset && armed), bounds.x + 4, bounds.y + 2,
					bounds.w - 6, color);
		}
	}

	private Window popupWindow() {
		if (main.popup != null) return main;
		if (event != null && event.popup != null) return event;
		return null;
	}

	/** The popup look of Veyl's {@code Popup}: title line, list, optional search and footer. */
	private void drawPopup(GuiGraphicsExtractor graphics, Window window, int mouseX, int mouseY) {
		Popup p = window.popup;
		Ui.shadow(graphics, p.x, p.y, p.w, p.h, 3, SHADOW, 4);
		Ui.roundedBorder(graphics, p.x, p.y, p.w, p.h, 3, BORDER, POPUP);
		Ui.textClipped(graphics, font, p.title, p.x + 6, p.y + 4, p.w - 12, TEXT_SECONDARY);

		int top = popupListTop(p);
		if (p.multi) drawPopupSearch(graphics, p, mouseX, mouseY);

		List<Option> options = p.filtered();
		int rows = popupRows(p);
		int listHeight = popupListHeight(p);
		int maxScroll = Math.max(0, options.size() - rows);
		p.scroll = Math.max(0, Math.min(p.scroll, maxScroll));
		int rowRight = p.x + p.w - (maxScroll > 0 ? 7 : 2);
		graphics.enableScissor(p.x + 2, top, p.x + p.w - 2, top + listHeight);
		for (int slot = 0; slot < rows; slot++) {
			int index = p.scroll + slot;
			if (index >= options.size()) break;
			Option option = options.get(index);
			int rowY = top + slot * POPUP_ROW;
			boolean hovered = mouseX >= p.x && mouseX < rowRight
					&& mouseY >= rowY && mouseY < rowY + POPUP_ROW;
			boolean selected = option.selected.getAsBoolean();
			if (hovered || selected) {
				Ui.rounded(graphics, p.x + 3, rowY, rowRight - (p.x + 3), POPUP_ROW, 3,
						selected ? Ui.withAlpha(ACCENT, 0.25f) : HOVER);
			}
			if (p.multi) {
				drawCheckbox(graphics, p.x + 5, rowY + 2, selected, 9);
				Ui.textClipped(graphics, font, option.label, p.x + 18, rowY + 3,
						rowRight - (p.x + 18) - 2, selected ? TEXT : TEXT_SECONDARY);
			} else {
				Ui.rounded(graphics, p.x + 4, rowY + 4, 2, POPUP_ROW - 8, 1, ACCENT);
				Ui.textClipped(graphics, font, option.label, p.x + 10, rowY + 3,
						rowRight - (p.x + 10) - 2, hovered ? TEXT : TEXT_SECONDARY);
			}
		}
		graphics.disableScissor();

		if (options.isEmpty()) {
			Ui.text(graphics, font, "No matches", p.x + 6, top + 3, TEXT_DISABLED);
		}
		if (maxScroll > 0) {
			drawPopupScrollbar(graphics, p, top, listHeight, rows, options.size(), maxScroll);
		}

		if (p.multi) {
			int footerY = top + listHeight + 3;
			drawPopupButton(graphics, popupButton(p, 0), "All", mouseX, mouseY);
			drawPopupButton(graphics, popupButton(p, 1), "None", mouseX, mouseY);
			drawPopupButton(graphics, popupButton(p, 2), "Done", mouseX, mouseY);
			long selected = p.options.stream().filter(option -> option.selected.getAsBoolean()).count();
			int summaryLeft = popupButton(p, 1).x + popupButton(p, 1).w + 4;
			int summaryRight = popupButton(p, 2).x - 4;
			if (summaryRight > summaryLeft) {
				Ui.textClipped(graphics, font, selected == 0 ? "none" : selected + " on",
						summaryLeft, footerY + 2, summaryRight - summaryLeft, TEXT_DISABLED);
			}
		}
	}

	private void drawPopupScrollbar(GuiGraphicsExtractor graphics, Popup p, int top, int height,
			int rows, int size, int maxScroll) {
		int x = p.x + p.w - 5;
		int thumbHeight = Math.max(10, height * rows / Math.max(1, size));
		int travel = Math.max(1, height - thumbHeight);
		int thumbY = top + Math.round((float) (p.scroll * travel) / Math.max(1, maxScroll));
		Ui.rounded(graphics, x, top, 3, height, 1, Ui.withAlpha(BORDER, 0.35f));
		Ui.rounded(graphics, x, thumbY, 3, thumbHeight, 1, SCROLLBAR);
	}

	private void drawPopupSearch(GuiGraphicsExtractor graphics, Popup p, int mouseX, int mouseY) {
		Bounds bounds = popupSearchBounds(p);
		Ui.roundedBorder(graphics, bounds.x, bounds.y, bounds.w, bounds.h, 2,
				p.searching ? ACCENT : BORDER, SEARCH_BAR);
		if (p.query.isEmpty()) {
			Ui.text(graphics, font, "Search...", bounds.x + 4, bounds.y + 2, TEXT_DISABLED);
			return;
		}
		Ui.textClipped(graphics, font, p.query, bounds.x + 4, bounds.y + 2, bounds.w - 12, TEXT);
		if (p.searching && (System.currentTimeMillis() / 500L) % 2L == 0L) {
			int caretX = bounds.x + 4 + font.width(p.query.substring(0, Math.min(p.caret, p.query.length())));
			if (caretX < bounds.x + bounds.w - 4) {
				Ui.rect(graphics, caretX, bounds.y + 2, 1, 9, ACCENT);
			}
		}
		boolean clearHover = mouseX >= bounds.x + bounds.w - 11 && mouseX <= bounds.x + bounds.w - 3
				&& mouseY >= bounds.y && mouseY <= bounds.y + bounds.h;
		Ui.text(graphics, font, "x", bounds.x + bounds.w - 9, bounds.y + 2, clearHover ? TEXT : TEXT_DISABLED);
	}

	private void drawPopupButton(GuiGraphicsExtractor graphics, Bounds bounds, String label,
			int mouseX, int mouseY) {
		boolean hovered = bounds.has(mouseX, mouseY);
		int fill = hovered ? Ui.mix(DROPDOWN, HOVER, 0.5f) : DROPDOWN;
		Ui.roundedBorder(graphics, bounds.x, bounds.y, bounds.w, bounds.h, 3, BORDER, fill);
		Ui.textCentered(graphics, font, label, bounds.x, bounds.w, bounds.y + 2, TEXT);
	}

	private void drawCheckbox(GuiGraphicsExtractor graphics, int x, int y, boolean selected, int size) {
		Ui.roundedBorder(graphics, x, y, size, size, 2,
				selected ? Ui.mix(ACCENT, 0xFFFFFFFF, 0.35f) : BORDER,
				selected ? ACCENT : CHECKBOX_OFF);
		if (selected) {
			Ui.textCenteredNoShadow(graphics, font, "x", x, size, y + 1, TEXT_ON_ACCENT);
		}
	}

	private String numberText(Row row) {
		return format(row.numberGet.getAsDouble(), row.decimals) + row.suffix;
	}

	private String rangeText(Row row) {
		return format(row.numberGet.getAsDouble(), row.decimals) + " - "
				+ format(row.rangeHigh.getAsDouble(), row.decimals) + row.suffix;
	}

	private static String format(double value, int decimals) {
		return decimals <= 0
				? Integer.toString((int) Math.round(value))
				: String.format(Locale.ROOT, "%." + decimals + "f", value);
	}

	private static double fraction(double value, double min, double max) {
		return Math.max(0, Math.min(1, (value - min) / Math.max(0.0001, max - min)));
	}

	// ---------------------------------------------------------------- input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() != 0) return false;

		clampWindow(main);
		clampWindow(this.event);
		layoutRows(main);
		layoutRows(this.event);

		double mouseX = event.x();
		double mouseY = event.y();

		Window popupOwner = popupWindow();
		if (popupOwner != null) return popupClicked(popupOwner, mouseX, mouseY);

		Window window = windowAt(mouseX, mouseY);
		if (window == null) {
			main.searching = false;
			if (this.event != null) this.event.searching = false;
			return false;
		}

		Window other = window == main ? this.event : main;
		if (other != null) other.searching = false;

		Bounds search = searchBounds(window);
		if (search.has(mouseX, mouseY)) {
			window.searching = true;
			if (!window.query.isEmpty() && mouseX >= search.x + search.w - 12) {
				window.query = "";
				window.caret = 0;
				window.scroll = 0;
			} else {
				window.caret = window.query.length();
			}
			return true;
		}
		window.searching = false;

		if (closeBounds(window).has(mouseX, mouseY)) {
			if (window.trigger == null) onClose();
			else closeEventWindow();
			return true;
		}

		if (footerBounds(window, 0).has(mouseX, mouseY)) {
			long now = System.currentTimeMillis();
			if (now < window.resetArmedUntil) {
				window.resetArmedUntil = 0;
				if (window.trigger == null) {
					config().resetSettings();
				} else {
					config().resetEvent(window.trigger);
				}
				SkinsPlus.get().settingsChanged();
				window.scroll = 0;
				window.caret = 0;
				window.query = "";
				clampScroll(window);
			} else {
				window.resetArmedUntil = now + RESET_ARM_MS;
			}
			return true;
		}
		if (footerBounds(window, 1).has(mouseX, mouseY)) {
			if (window.trigger == null) onClose();
			else closeEventWindow();
			return true;
		}

		if (mouseX >= window.x && mouseX <= window.x + WINDOW_WIDTH
				&& mouseY >= window.y && mouseY <= window.y + HEADER) {
			draggingWindow = window;
			window.dragging = true;
			window.dragOffsetX = (int) mouseX - window.x;
			window.dragOffsetY = (int) mouseY - window.y;
			return true;
		}

		if (startScrollbarDrag(window, mouseX, mouseY)) return true;

		if (mouseX < window.x || mouseX > window.x + WINDOW_WIDTH
				|| mouseY < bodyTop(window) || mouseY > bodyTop(window) + bodyViewport(window)) {
			return true;
		}

		for (Row row : visibleRows(window)) {
			if (mouseX < row.x || mouseX >= row.x + row.w
					|| mouseY < row.y || mouseY >= row.y + row.height) {
				continue;
			}
			if (clickRow(window, row, mouseX, mouseY)) return true;
		}
		return true;
	}

	private boolean clickRow(Window window, Row row, double mouseX, double mouseY) {
		switch (row.kind) {
			case BOOLEAN -> {
				row.boolSet.accept(!row.boolGet.getAsBoolean());
				return true;
			}
			case ENUM -> {
				Bounds control = enumControl(row);
				if (control.has(mouseX, mouseY)) {
					openPopup(window, row, false);
					return true;
				}
			}
			case MULTI -> {
				Bounds control = multiControl(row);
				if (control.has(mouseX, mouseY)) {
					openPopup(window, row, true);
					return true;
				}
			}
			case NUMBER -> {
				Bounds track = numberTrack(row);
				if (track.containsExpanded(mouseX, mouseY, 4)) {
					slidingRow = row;
					rangeHandle = 0;
					setSliderFromMouse(row, mouseX);
					return true;
				}
			}
			case RANGE -> {
				Bounds track = rangeTrack(row);
				if (track.containsExpanded(mouseX, mouseY, 4)) {
					slidingRow = row;
					rangeHandle = nearestHandle(row, mouseX);
					setSliderFromMouse(row, mouseX);
					return true;
				}
			}
			case EVENT -> {
				if (eventCheckbox(row).has(mouseX, mouseY)) {
					Config.EventSettings settings = config().event(row.trigger);
					if (settings != null) {
						settings.enabled = !settings.enabled;
						SkinsPlus.get().settingsChanged();
					}
					return true;
				}
				if (gearBounds(row).has(mouseX, mouseY)) {
					toggleEventWindow(row.trigger);
					return true;
				}
			}
			default -> {
			}
		}
		return false;
	}

	private void toggleEventWindow(Trigger trigger) {
		main.searching = false;
		main.popup = null;
		if (event != null && event.trigger == trigger) {
			closeEventWindow();
			return;
		}

		Window window = new Window(trigger.label(), trigger);
		buildEventRows(window, trigger);

		int x = event != null ? event.x : config().eventWindowX;
		int y = event != null ? event.y : config().eventWindowY;
		if (x < 0 || y < 0) {
			x = main.x + WINDOW_WIDTH + 8;
			if (x + WINDOW_WIDTH > width - 8) x = main.x - WINDOW_WIDTH - 8;
			if (x < 8) x = Math.min(main.x + 24, width - WINDOW_WIDTH - 8);
			y = main.y;
		}
		window.x = Math.max(8, Math.min(x, Math.max(8, width - WINDOW_WIDTH - 8)));
		window.y = Math.max(8, Math.min(y, Math.max(8, height - frameHeight(window) - 8)));
		event = window;
	}

	private void closeEventWindow() {
		if (event == null) return;
		config().eventWindowX = event.x;
		config().eventWindowY = event.y;
		config().saveSoon();
		event = null;
	}

	private void setSliderFromMouse(Row row, double mouseX) {
		Bounds track = row.kind == Kind.RANGE ? rangeTrack(row) : numberTrack(row);
		double fraction = Math.max(0, Math.min(1, (mouseX - track.x) / Math.max(1, track.w)));
		double value = row.min + fraction * (row.max - row.min);
		if (row.step > 0) value = Math.round(value / row.step) * row.step;
		value = Math.max(row.min, Math.min(row.max, value));

		if (row.kind == Kind.NUMBER) {
			row.numberSet.accept(value);
		} else {
			double low = row.numberGet.getAsDouble();
			double high = row.rangeHigh.getAsDouble();
			if (rangeHandle == 0) low = Math.min(value, high);
			else high = Math.max(value, low);
			row.rangeSet.accept(low, high);
		}
		SkinsPlus.get().valuesChanged();
	}

	private int nearestHandle(Row row, double mouseX) {
		Bounds track = rangeTrack(row);
		double lowX = track.x + track.w * fraction(row.numberGet.getAsDouble(), row.min, row.max);
		double highX = track.x + track.w * fraction(row.rangeHigh.getAsDouble(), row.min, row.max);
		return Math.abs(mouseX - lowX) <= Math.abs(mouseX - highX) ? 0 : 1;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
		if (draggingWindow != null) {
			draggingWindow.x = (int) event.x() - draggingWindow.dragOffsetX;
			draggingWindow.y = (int) event.y() - draggingWindow.dragOffsetY;
			return true;
		}
		if (slidingRow != null) {
			setSliderFromMouse(slidingRow, event.x());
			return true;
		}
		if (draggingScrollbar) {
			dragScrollbarTo(scrollbarWindow, event.y());
			return true;
		}
		return super.mouseDragged(event, dragX, dragY);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		boolean wasScrollbar = draggingScrollbar;
		boolean handled = draggingWindow != null || slidingRow != null || draggingScrollbar;
		if (draggingWindow != null) draggingWindow.dragging = false;
		draggingWindow = null;
		slidingRow = null;
		draggingScrollbar = false;
		if (wasScrollbar) clampScroll(scrollbarWindow);
		if (handled) {
			clampWindow(main);
			clampWindow(this.event);
			savePositions();
		}
		return handled;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		Window popupOwner = popupWindow();
		if (popupOwner != null) {
			Popup p = popupOwner.popup;
			int rows = popupRows(p);
			int max = Math.max(0, p.filtered().size() - rows);
			p.scroll = Math.max(0, Math.min(max, p.scroll - (int) Math.signum(scrollY) * 2));
			return true;
		}
		Window window = windowAt(mouseX, mouseY);
		if (window != null) {
			if (maxScroll(window) > 0) {
				window.scroll -= (int) Math.signum(scrollY) * 12;
				clampScroll(window);
			}
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
			Window popupOwner = popupWindow();
			if (popupOwner != null) {
				closePopup(popupOwner);
				return true;
			}
			Window focused = focusedWindow();
			if (focused != null) {
				focused.searching = false;
				return true;
			}
			if (this.event != null) {
				closeEventWindow();
				return true;
			}
			if (main.searching) {
				main.searching = false;
				return true;
			}
			return super.keyPressed(event);
		}

		Window popupOwner = popupWindow();
		if (popupOwner != null) return popupKeyPressed(popupOwner, event);

		Window focused = focusedWindow();
		if (focused == null) return super.keyPressed(event);
		return searchKeyPressed(focused, event);
	}

	private Window focusedWindow() {
		if (event != null && event.searching) return event;
		if (main.searching) return main;
		return null;
	}

	private boolean searchKeyPressed(Window window, KeyEvent event) {
		switch (event.key()) {
			case GLFW.GLFW_KEY_BACKSPACE -> {
				if (window.caret > 0) {
					window.query = window.query.substring(0, window.caret - 1) + window.query.substring(window.caret);
					window.caret--;
					window.scroll = 0;
				}
				return true;
			}
			case GLFW.GLFW_KEY_DELETE -> {
				if (window.caret < window.query.length()) {
					window.query = window.query.substring(0, window.caret) + window.query.substring(window.caret + 1);
					window.scroll = 0;
				}
				return true;
			}
			case GLFW.GLFW_KEY_LEFT -> {
				window.caret = Math.max(0, window.caret - 1);
				return true;
			}
			case GLFW.GLFW_KEY_RIGHT -> {
				window.caret = Math.min(window.query.length(), window.caret + 1);
				return true;
			}
			case GLFW.GLFW_KEY_HOME -> {
				window.caret = 0;
				return true;
			}
			case GLFW.GLFW_KEY_END -> {
				window.caret = window.query.length();
				return true;
			}
			case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
				window.searching = false;
				return true;
			}
			default -> {
				return false;
			}
		}
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		Window popupOwner = popupWindow();
		if (popupOwner != null) return popupCharTyped(popupOwner, event);

		Window focused = focusedWindow();
		if (focused == null) return false;
		int codepoint = event.codepoint();
		if (codepoint < 32 || codepoint == 127) return false;
		String inserted = new String(Character.toChars(codepoint));
		if (focused.query.length() + inserted.length() > 64) return false;
		focused.query = focused.query.substring(0, focused.caret) + inserted + focused.query.substring(focused.caret);
		focused.caret += inserted.length();
		focused.scroll = 0;
		return true;
	}

	// ---------------------------------------------------------------- popups

	private void openPopup(Window window, Row row, boolean multi) {
		List<Option> options = row.options.get();
		if (options.isEmpty()) return;
		main.popup = null;
		if (event != null) event.popup = null;
		window.searching = false;

		int widest = 0;
		for (Option option : options) widest = Math.max(widest, font.width(option.label));
		int popupWidth = multi ? Math.max(180, widest + 36) : Math.max(110, widest + 18);
		popupWidth = Math.min(Math.min(popupWidth, 340), Math.max(90, width - 16));
		int rows = Math.min(options.size(), MAX_POPUP_ROWS);
		int popupHeight = 8 + POPUP_TITLE + (multi ? POPUP_SEARCH + POPUP_FOOTER : 0) + rows * POPUP_ROW;

		Bounds anchor = multi ? multiControl(row) : enumControl(row);
		int popupX = anchor.x + anchor.w - popupWidth;
		int popupY = anchor.y + anchor.h + 1;
		popupX = Math.max(8, Math.min(popupX, width - popupWidth - 8));
		if (popupY + popupHeight > height - 8) popupY = anchor.y - popupHeight - 1;
		popupY = Math.max(8, Math.min(popupY, height - popupHeight - 8));

		window.popup = new Popup(popupX, popupY, popupWidth, popupHeight, row.label, options, multi);
	}

	private void closePopup(Window window) {
		if (window == null) return;
		window.popup = null;
		clampWindow(window);
		clampScroll(window);
	}

	private int popupListTop(Popup p) {
		return p.y + 4 + POPUP_TITLE + (p.multi ? POPUP_SEARCH : 0);
	}

	private int popupRows(Popup p) {
		return Math.min(Math.max(1, p.options.size()), MAX_POPUP_ROWS);
	}

	private int popupListHeight(Popup p) {
		return popupRows(p) * POPUP_ROW;
	}

	private Bounds popupSearchBounds(Popup p) {
		return new Bounds(p.x + 4, p.y + 4 + POPUP_TITLE, p.w - 8, 12);
	}

	private boolean popupClicked(Window window, double mouseX, double mouseY) {
		Popup p = window.popup;
		if (mouseX < p.x || mouseX > p.x + p.w || mouseY < p.y || mouseY > p.y + p.h) {
			closePopup(window);
			return true;
		}

		if (p.multi) {
			Bounds search = popupSearchBounds(p);
			if (search.has(mouseX, mouseY)) {
				if (!p.query.isEmpty() && mouseX >= search.x + search.w - 11) {
					p.query = "";
					p.caret = 0;
					p.scroll = 0;
				} else {
					p.searching = true;
					p.caret = p.query.length();
				}
				return true;
			}
			p.searching = false;
		}

		int top = popupListTop(p);
		int listHeight = popupListHeight(p);
		if (mouseY >= top && mouseY < top + listHeight) {
			List<Option> options = p.filtered();
			int index = p.scroll + (int) ((mouseY - top) / POPUP_ROW);
			if (index >= 0 && index < options.size()) {
				options.get(index).toggle.run();
				if (!p.multi) closePopup(window);
			}
			return true;
		}

		if (p.multi) {
			if (popupButton(p, 0).has(mouseX, mouseY)) {
				for (Option option : p.options) if (!option.selected.getAsBoolean()) option.toggle.run();
				return true;
			}
			if (popupButton(p, 1).has(mouseX, mouseY)) {
				for (Option option : p.options) if (option.selected.getAsBoolean()) option.toggle.run();
				return true;
			}
			if (popupButton(p, 2).has(mouseX, mouseY)) {
				closePopup(window);
				return true;
			}
		}
		return true;
	}

	private Bounds popupButton(Popup p, int index) {
		int y = popupListTop(p) + popupListHeight(p) + 3;
		return switch (index) {
			case 0 -> new Bounds(p.x + 5, y, 34, POPUP_FOOTER - 2);
			case 1 -> new Bounds(p.x + 42, y, 42, POPUP_FOOTER - 2);
			default -> new Bounds(p.x + p.w - 41, y, 36, POPUP_FOOTER - 2);
		};
	}

	private boolean popupKeyPressed(Window window, KeyEvent event) {
		Popup p = window.popup;
		if (p == null || !p.multi || !p.searching) return false;
		switch (event.key()) {
			case GLFW.GLFW_KEY_BACKSPACE -> {
				if (p.caret > 0) {
					p.query = p.query.substring(0, p.caret - 1) + p.query.substring(p.caret);
					p.caret--;
					p.scroll = 0;
				}
				return true;
			}
			case GLFW.GLFW_KEY_DELETE -> {
				if (p.caret < p.query.length()) {
					p.query = p.query.substring(0, p.caret) + p.query.substring(p.caret + 1);
					p.scroll = 0;
				}
				return true;
			}
			case GLFW.GLFW_KEY_LEFT -> {
				p.caret = Math.max(0, p.caret - 1);
				return true;
			}
			case GLFW.GLFW_KEY_RIGHT -> {
				p.caret = Math.min(p.query.length(), p.caret + 1);
				return true;
			}
			case GLFW.GLFW_KEY_HOME -> {
				p.caret = 0;
				return true;
			}
			case GLFW.GLFW_KEY_END -> {
				p.caret = p.query.length();
				return true;
			}
			case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
				p.searching = false;
				return true;
			}
			default -> {
				return false;
			}
		}
	}

	private boolean popupCharTyped(Window window, CharacterEvent event) {
		Popup p = window.popup;
		if (p == null || !p.multi || !p.searching) return false;
		int codepoint = event.codepoint();
		if (codepoint < 32 || codepoint == 127) return false;
		String inserted = new String(Character.toChars(codepoint));
		if (p.query.length() + inserted.length() > 48) return false;
		p.query = p.query.substring(0, p.caret) + inserted + p.query.substring(p.caret);
		p.caret += inserted.length();
		p.scroll = 0;
		return true;
	}

	// ---------------------------------------------------------------- scrollbar

	private boolean startScrollbarDrag(Window window, double mouseX, double mouseY) {
		int[] thumb = scrollbarThumb(window);
		if (thumb == null) return false;
		Bounds track = scrollbarTrack(window);
		if (mouseX < track.x - SCROLLBAR_GRAB || mouseX > track.x + track.w + SCROLLBAR_GRAB) return false;
		if (mouseY < track.y || mouseY > track.y + track.h) return false;

		boolean onThumb = mouseY >= thumb[0] && mouseY <= thumb[0] + thumb[1];
		scrollbarGrab = onThumb ? (int) mouseY - thumb[0] : thumb[1] / 2;
		draggingScrollbar = true;
		scrollbarWindow = window;
		dragScrollbarTo(window, mouseY);
		return true;
	}

	private void dragScrollbarTo(Window window, double mouseY) {
		int[] thumb = scrollbarThumb(window);
		if (thumb == null) return;
		Bounds track = scrollbarTrack(window);
		int travel = Math.max(1, track.h - thumb[1]);
		float ratio = (float) ((mouseY - scrollbarGrab - track.y) / travel);
		ratio = Math.max(0, Math.min(1, ratio));
		window.scroll = Math.round(ratio * maxScroll(window));
		clampScroll(window);
	}

	// ---------------------------------------------------------------- persistence

	private void savePositions() {
		Config config = config();
		config.windowX = main.x;
		config.windowY = main.y;
		config.windowScroll = main.scroll;
		if (event != null) {
			config.eventWindowX = event.x;
			config.eventWindowY = event.y;
		}
		config.saveSoon();
	}

	@Override
	public void removed() {
		Config config = config();
		config.windowX = main.x;
		config.windowY = main.y;
		config.windowScroll = main.scroll;
		if (event != null) {
			config.eventWindowX = event.x;
			config.eventWindowY = event.y;
		}
		config.save();
	}

	// ---------------------------------------------------------------- model

	private enum Kind {
		BOOLEAN, ENUM, MULTI, NUMBER, RANGE, EVENT, HEADER
	}

	private static final class Window {
		private final String title;
		private final Trigger trigger;
		private final List<Row> rows = new ArrayList<>();
		private int x;
		private int y;
		private int scroll;
		private String query = "";
		private int caret;
		private boolean searching;
		private Popup popup;
		private boolean dragging;
		private int dragOffsetX;
		private int dragOffsetY;
		private long resetArmedUntil;

		private Window(String title, Trigger trigger) {
			this.title = title;
			this.trigger = trigger;
		}
	}

	private static final class Row {
		private final Kind kind;
		private final String label;
		private final String description;
		private final int height;
		private BooleanSupplier visible = () -> true;
		private int x;
		private int y;
		private int w;

		private Trigger trigger;
		private BooleanSupplier boolGet;
		private Consumer<Boolean> boolSet;
		private Supplier<String> enumText;
		private Supplier<String> multiText;
		private Supplier<List<Option>> options;
		private DoubleSupplier numberGet;
		private DoubleConsumer numberSet;
		private DoubleSupplier rangeHigh;
		private BiConsumer<Double, Double> rangeSet;
		private double min;
		private double max;
		private double step;
		private String suffix = "";
		private int decimals;

		private Row(Kind kind, String label, String description, int height) {
			this.kind = kind;
			this.label = label;
			this.description = description;
			this.height = height;
		}
	}

	private static final class Option {
		private final String label;
		private final BooleanSupplier selected;
		private final Runnable toggle;

		private Option(String label, BooleanSupplier selected, Runnable toggle) {
			this.label = label;
			this.selected = selected;
			this.toggle = toggle;
		}
	}

	private static final class Popup {
		private final int x;
		private final int y;
		private final int w;
		private final int h;
		private final String title;
		private final List<Option> options;
		private final boolean multi;
		private String query = "";
		private int caret;
		private int scroll;
		private boolean searching;

		private Popup(int x, int y, int w, int h, String title, List<Option> options, boolean multi) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.title = title;
			this.options = options;
			this.multi = multi;
		}

		/** Options left after the picker's own search field has been applied. */
		private List<Option> filtered() {
			if (query.isBlank()) return options;
			String needle = query.trim().toLowerCase(Locale.ROOT);
			List<Option> out = new ArrayList<>();
			for (Option option : options) {
				if (option.label.toLowerCase(Locale.ROOT).contains(needle)) out.add(option);
			}
			return out;
		}
	}

	private record Bounds(int x, int y, int w, int h) {
		private boolean has(double mouseX, double mouseY) {
			return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
		}

		private boolean containsExpanded(double mouseX, double mouseY, int slack) {
			return mouseX >= x && mouseX < x + w
					&& mouseY >= y - slack && mouseY < y + h + slack;
		}
	}
}
