package com.skinsplus.mixin;

import com.skinsplus.SkinsPlus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Writes Skins+' visible-part mask into the local player's render state. */
@Mixin(AvatarRenderer.class)
public abstract class AvatarOuterLayerMixin {

	@Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;"
			+ "Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V", at = @At("TAIL"))
	private void skinsplus$applyOuterLayer(Avatar avatar, AvatarRenderState state, float partialTick,
			CallbackInfo callback) {
		SkinsPlus effect = SkinsPlus.get();
		if (!effect.isEnabled()) return;

		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft == null || avatar != minecraft.player) return;

		int shown = effect.shownMask();
		Options options = minecraft.options;

		if (effect.owns(PlayerModelPart.HAT)) {
			state.showHat = visible(shown, PlayerModelPart.HAT) && options.isModelPartEnabled(PlayerModelPart.HAT);
		}
		if (effect.owns(PlayerModelPart.JACKET)) {
			state.showJacket = visible(shown, PlayerModelPart.JACKET)
					&& options.isModelPartEnabled(PlayerModelPart.JACKET);
		}
		if (effect.owns(PlayerModelPart.LEFT_SLEEVE)) {
			state.showLeftSleeve = visible(shown, PlayerModelPart.LEFT_SLEEVE)
					&& options.isModelPartEnabled(PlayerModelPart.LEFT_SLEEVE);
		}
		if (effect.owns(PlayerModelPart.RIGHT_SLEEVE)) {
			state.showRightSleeve = visible(shown, PlayerModelPart.RIGHT_SLEEVE)
					&& options.isModelPartEnabled(PlayerModelPart.RIGHT_SLEEVE);
		}
		if (effect.owns(PlayerModelPart.LEFT_PANTS_LEG)) {
			state.showLeftPants = visible(shown, PlayerModelPart.LEFT_PANTS_LEG)
					&& options.isModelPartEnabled(PlayerModelPart.LEFT_PANTS_LEG);
		}
		if (effect.owns(PlayerModelPart.RIGHT_PANTS_LEG)) {
			state.showRightPants = visible(shown, PlayerModelPart.RIGHT_PANTS_LEG)
					&& options.isModelPartEnabled(PlayerModelPart.RIGHT_PANTS_LEG);
		}
		if (effect.owns(PlayerModelPart.CAPE)) {
			state.showCape = state.showCape && visible(shown, PlayerModelPart.CAPE);
		}
	}

	private static boolean visible(int mask, PlayerModelPart part) {
		return (mask & part.getMask()) != 0;
	}
}
