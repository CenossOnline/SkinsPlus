package com.skinsplus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Everything Skins+ remembers between launches, in one readable JSON file. */
public final class Config {
	private static final Logger LOGGER = LoggerFactory.getLogger("Skins+");
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("skinsplus.json");
	/** Save at most this often while a slider is being dragged. */
	private static final long SAVE_DEBOUNCE_MS = 350L;
	/** Value the previous config format used for a disabled event. */
	private static final String LEGACY_OFF = "OFF";

	private static final List<String> DEFAULT_PARTS = List.of(
			"HAT", "JACKET", "LEFT_SLEEVE", "RIGHT_SLEEVE", "LEFT_PANTS_LEG", "RIGHT_PANTS_LEG");

	private static Config instance;

	public boolean enabled = false;

	/** Main-window speed, used by every event that follows the global speed. */
	public double speed = 4.0;
	/** Main-window duty cycle, used by every event that follows the global duty. */
	public double duty = 50.0;

	public double intervalMin = 1.0;
	public double intervalMax = 8.0;
	public double chaosRunMin = 2.0;
	public double chaosRunMax = 5.0;
	public double chaosPause = 1.0;
	/** How many speed cycles each Random cycle pattern lasts. */
	public int shuffleEvery = 4;

	/** Fire only a fixed number of times inside each window, at random moments. */
	public boolean bursts = false;
	public int burstCount = 6;
	/** Window length in seconds. */
	public double burstWindow = 60.0;
	/** How long each burst lasts, in seconds. */
	public double burstLength = 0.6;

	public Set<String> parts = new LinkedHashSet<>(DEFAULT_PARTS);
	/** Per-event settings, keyed by {@code Trigger.name()}; filled with defaults by {@link #sanitize()}. */
	public Map<String, EventSettings> eventSettings;
	/** Previous format's map of event name to animation name; read once, then dropped. */
	public Map<String, String> events;

	public double triggerRadius = 16.0;
	public double healthThreshold = 6.0;
	public boolean visibleToOthers = true;

	/** Top-left of the main settings window; -1 means "centre it". */
	public int windowX = -1;
	public int windowY = -1;
	/** Top-left of the per-event window; -1 means "beside the main window". */
	public int eventWindowX = -1;
	public int eventWindowY = -1;
	/** Scroll offset inside the settings list, remembered between sessions. */
	public int windowScroll = 0;

	private boolean dirty;
	private long dirtyAt;

	/** One event's own animation and optional overrides; null speed/duty means "follow global". */
	public static final class EventSettings {
		public boolean enabled = true;
		public String animation = SkinsPlus.Animation.TOGETHER.name();
		public Double speed;
		public Double duty;
	}

	private Config() {
	}

	public static Config get() {
		return instance;
	}

	/** Reads the saved file, or starts from defaults. Never leaves {@link #get()} null. */
	public static void load() {
		Config config = null;
		if (Files.isRegularFile(FILE)) {
			try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
				config = GSON.fromJson(reader, Config.class);
			} catch (IOException | RuntimeException error) {
				LOGGER.warn("[Skins+] Could not read {}: {}", FILE, error.toString());
			}
		}
		if (config == null) config = new Config();
		config.sanitize();
		instance = config;
	}

	private static Map<String, EventSettings> defaultEventSettings() {
		Map<String, EventSettings> map = new LinkedHashMap<>();
		addEvent(map, SkinsPlus.Trigger.ALWAYS, SkinsPlus.Animation.TOGETHER);
		addEvent(map, SkinsPlus.Trigger.DAMAGE, SkinsPlus.Animation.GLITCH);
		addEvent(map, SkinsPlus.Trigger.LOW_HEALTH, SkinsPlus.Animation.STROBE);
		addEvent(map, SkinsPlus.Trigger.NEARBY, SkinsPlus.Animation.CASCADE);
		addEvent(map, SkinsPlus.Trigger.SPRINTING, SkinsPlus.Animation.MARQUEE);
		addEvent(map, SkinsPlus.Trigger.SNEAKING, SkinsPlus.Animation.SPLIT);
		return map;
	}

	private static void addEvent(Map<String, EventSettings> map, SkinsPlus.Trigger trigger,
			SkinsPlus.Animation animation) {
		EventSettings settings = new EventSettings();
		settings.animation = animation.name();
		map.put(trigger.name(), settings);
	}

	private void sanitize() {
		speed = clamp(speed, 0.5, 20.0);
		duty = clamp(duty, 5.0, 95.0);
		intervalMin = clamp(intervalMin, 0.5, 20.0);
		intervalMax = clamp(intervalMax, 0.5, 20.0);
		chaosRunMin = clamp(chaosRunMin, 0.5, 15.0);
		chaosRunMax = clamp(chaosRunMax, 0.5, 15.0);
		chaosPause = clamp(chaosPause, 0.1, 5.0);
		shuffleEvery = (int) clamp(shuffleEvery, 1, 16);
		burstCount = (int) clamp(burstCount, 1, 30);
		burstWindow = clamp(burstWindow, 5.0, 600.0);
		burstLength = clamp(burstLength, 0.1, 5.0);
		triggerRadius = clamp(triggerRadius, 2.0, 64.0);
		healthThreshold = clamp(healthThreshold, 1.0, 20.0);
		windowScroll = Math.max(0, windowScroll);

		if (parts == null) parts = new LinkedHashSet<>(DEFAULT_PARTS);
		Set<String> knownParts = new LinkedHashSet<>();
		for (String name : parts) {
			SkinsPlus.Part part = SkinsPlus.Part.byName(name);
			if (part != null) knownParts.add(part.name());
		}
		parts = knownParts;

		Map<String, EventSettings> defaults = defaultEventSettings();
		Map<String, EventSettings> fixed = new LinkedHashMap<>();
		for (SkinsPlus.Trigger trigger : SkinsPlus.Trigger.values()) {
			fixed.put(trigger.name(), sanitizeEvent(trigger, defaults.get(trigger.name())));
		}
		eventSettings = fixed;
		// The old string map has been folded into eventSettings; stop writing it.
		events = null;
	}

	private EventSettings sanitizeEvent(SkinsPlus.Trigger trigger, EventSettings defaults) {
		EventSettings stored = eventSettings == null ? null : eventSettings.get(trigger.name());
		EventSettings out = new EventSettings();
		out.enabled = defaults.enabled;
		out.animation = defaults.animation;

		if (stored == null) {
			// Configs written by the previous version kept a map of strings instead.
			String legacy = events == null ? null : events.get(trigger.name());
			if (legacy != null) {
				SkinsPlus.Animation animation = SkinsPlus.Animation.byName(legacy);
				if (animation != null) out.animation = animation.name();
				else if (LEGACY_OFF.equalsIgnoreCase(legacy)) out.enabled = false;
			}
			return out;
		}

		out.enabled = stored.enabled;
		SkinsPlus.Animation animation = SkinsPlus.Animation.byName(stored.animation);
		if (animation != null) out.animation = animation.name();
		out.speed = stored.speed == null ? null : clamp(stored.speed, 0.5, 20.0);
		out.duty = stored.duty == null ? null : clamp(stored.duty, 5.0, 95.0);
		return out;
	}

	private static double clamp(double value, double min, double max) {
		return Math.max(min, Math.min(max, value));
	}

	/** This event's settings block. */
	public EventSettings event(SkinsPlus.Trigger trigger) {
		return eventSettings.get(trigger.name());
	}

	/** The animation this event plays; falls back to Together if the file was hand-edited. */
	public SkinsPlus.Animation animation(SkinsPlus.Trigger trigger) {
		EventSettings settings = event(trigger);
		SkinsPlus.Animation animation = settings == null ? null : SkinsPlus.Animation.byName(settings.animation);
		return animation == null ? SkinsPlus.Animation.TOGETHER : animation;
	}

	/** This event's speed: its own override, or the main window's value. */
	public double speedFor(SkinsPlus.Trigger trigger) {
		EventSettings settings = event(trigger);
		return settings == null || settings.speed == null ? speed : settings.speed;
	}

	/** This event's duty cycle: its own override, or the main window's value. */
	public double dutyFor(SkinsPlus.Trigger trigger) {
		EventSettings settings = event(trigger);
		return settings == null || settings.duty == null ? duty : settings.duty;
	}

	/** The animation every event shares, or null when they differ. */
	public SkinsPlus.Animation commonAnimation() {
		SkinsPlus.Animation common = null;
		for (SkinsPlus.Trigger trigger : SkinsPlus.Trigger.values()) {
			SkinsPlus.Animation animation = animation(trigger);
			if (common == null) common = animation;
			else if (common != animation) return null;
		}
		return common;
	}

	/** Sets every event to the same animation; each event can still be changed afterwards. */
	public void setAllAnimations(SkinsPlus.Animation animation) {
		for (SkinsPlus.Trigger trigger : SkinsPlus.Trigger.values()) {
			EventSettings settings = event(trigger);
			if (settings != null) settings.animation = animation.name();
		}
		saveSoon();
	}

	/** True when at least one enabled event uses this animation (drives contextual timing rows). */
	public boolean usesAnimation(SkinsPlus.Animation animation) {
		for (SkinsPlus.Trigger trigger : SkinsPlus.Trigger.values()) {
			EventSettings settings = event(trigger);
			if (settings != null && settings.enabled && animation(trigger) == animation) return true;
		}
		return false;
	}

	/** Restores one event to its shipped settings. */
	public void resetEvent(SkinsPlus.Trigger trigger) {
		EventSettings defaults = defaultEventSettings().get(trigger.name());
		eventSettings.put(trigger.name(), defaults);
		saveSoon();
	}

	/** Restores every setting to its shipped value, keeping the window where the user put it. */
	public void resetSettings() {
		Config fresh = new Config();
		fresh.sanitize();
		enabled = fresh.enabled;
		speed = fresh.speed;
		duty = fresh.duty;
		intervalMin = fresh.intervalMin;
		intervalMax = fresh.intervalMax;
		chaosRunMin = fresh.chaosRunMin;
		chaosRunMax = fresh.chaosRunMax;
		chaosPause = fresh.chaosPause;
		shuffleEvery = fresh.shuffleEvery;
		bursts = fresh.bursts;
		burstCount = fresh.burstCount;
		burstWindow = fresh.burstWindow;
		burstLength = fresh.burstLength;
		parts = fresh.parts;
		eventSettings = fresh.eventSettings;
		triggerRadius = fresh.triggerRadius;
		healthThreshold = fresh.healthThreshold;
		visibleToOthers = fresh.visibleToOthers;
		windowScroll = 0;
		saveSoon();
	}

	/** Marks the file dirty; the client tick writes it once the user stops editing. */
	public void saveSoon() {
		dirty = true;
		dirtyAt = System.currentTimeMillis();
	}

	/** Called every client tick. Writes only after a short quiet period. */
	public void flush() {
		if (!dirty || System.currentTimeMillis() - dirtyAt < SAVE_DEBOUNCE_MS) return;
		save();
	}

	public void save() {
		dirty = false;
		Path temporary = FILE.resolveSibling(FILE.getFileName() + ".tmp");
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
			try {
				Files.move(temporary, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException error) {
				Files.move(temporary, FILE, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException error) {
			LOGGER.warn("[Skins+] Could not save {}: {}", FILE, error.toString());
		}
	}
}
