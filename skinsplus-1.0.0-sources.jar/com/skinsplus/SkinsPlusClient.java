package com.skinsplus;

import com.mojang.blaze3d.platform.InputConstants;
import com.skinsplus.gui.SkinsPlusScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client entrypoint: owns the key binds and the once-per-tick housekeeping. */
public final class SkinsPlusClient implements ClientModInitializer {
	public static final String MOD_ID = "skinsplus";
	public static final Logger LOGGER = LoggerFactory.getLogger("Skins+");

	private static final KeyMapping.Category CATEGORY =
			KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

	private static KeyMapping openKey;
	private static KeyMapping toggleKey;

	/** The toggle key as the game spells it, or an empty string when it is unbound. */
	public static String toggleKeyLabel() {
		return toggleKey == null || toggleKey.isUnbound() ? "" : toggleKey.getTranslatedKeyMessage().getString();
	}

	@Override
	public void onInitializeClient() {
		Config.load();

		openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.skinsplus.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
		toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.skinsplus.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY));

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.get().save());

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.consumeClick()) {
				if (client.gui.screen() == null) client.setScreenAndShow(new SkinsPlusScreen());
			}
			while (toggleKey.consumeClick()) {
				SkinsPlus.get().toggle();
			}

			SkinsPlus.get().tick(client);
			Config.get().flush();
		});
	}
}
