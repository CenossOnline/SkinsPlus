package com.skinsplus;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelPart;

import java.util.Random;

/**
 * The effect itself: which parts of the local player's outer skin layer are visible right now,
 * the animation each event plays, and the optional mirror of that state to the server.
 */
public final class SkinsPlus {
	public enum Animation {
		TOGETHER("Together", true),
		CASCADE("Cascade", true),
		MARQUEE("Marquee", true),
		ALTERNATE("Alternate", true),
		SPLIT("Split", true),
		GLITCH("Glitch", true),
		WAVE("Wave", true),
		CHECKER("Checker", true),
		ZIGZAG("Zigzag", true),
		RIPPLE("Ripple", true),
		STROBE("Strobe", true),
		GROW("Grow", true),
		RANDOM("Random", false),
		CHAOS("Random pattern", false),
		SHUFFLE("Random cycle", false);

		private final String label;
		private final boolean shape;

		Animation(String label, boolean shape) {
			this.label = label;
			this.shape = shape;
		}

		public String label() {
			return label;
		}

		/** True for animations that lay parts out in a shape; the random modes drive themselves. */
		public boolean isShape() {
			return shape;
		}

		public static Animation byName(String name) {
			if (name == null) return null;
			for (Animation animation : values()) {
				if (animation.name().equalsIgnoreCase(name) || animation.label.equalsIgnoreCase(name)) {
					return animation;
				}
			}
			return null;
		}
	}

	public enum Trigger {
		ALWAYS("Always"),
		DAMAGE("Taking damage"),
		NEARBY("Player nearby"),
		LOW_HEALTH("Low health"),
		SPRINTING("Sprinting"),
		SNEAKING("Sneaking");

		private final String label;

		Trigger(String label) {
			this.label = label;
		}

		public String label() {
			return label;
		}

		public static Trigger byName(String name) {
			if (name == null) return null;
			for (Trigger trigger : values()) {
				if (trigger.name().equalsIgnoreCase(name)) return trigger;
			}
			return null;
		}
	}

	public enum Part {
		HAT(PlayerModelPart.HAT, "Hat"),
		JACKET(PlayerModelPart.JACKET, "Jacket"),
		LEFT_SLEEVE(PlayerModelPart.LEFT_SLEEVE, "Left sleeve"),
		RIGHT_SLEEVE(PlayerModelPart.RIGHT_SLEEVE, "Right sleeve"),
		LEFT_PANTS_LEG(PlayerModelPart.LEFT_PANTS_LEG, "Left pant"),
		RIGHT_PANTS_LEG(PlayerModelPart.RIGHT_PANTS_LEG, "Right pant"),
		CAPE(PlayerModelPart.CAPE, "Cape");

		private final PlayerModelPart modelPart;
		private final String label;

		Part(PlayerModelPart modelPart, String label) {
			this.modelPart = modelPart;
			this.label = label;
		}

		public PlayerModelPart modelPart() {
			return modelPart;
		}

		public String label() {
			return label;
		}

		public static Part byName(String name) {
			if (name == null) return null;
			for (Part part : values()) {
				if (part.name().equalsIgnoreCase(name) || part.label.equalsIgnoreCase(name)) return part;
			}
			return null;
		}

		public static Part byModelPart(PlayerModelPart part) {
			for (Part candidate : values()) {
				if (candidate.modelPart == part) return candidate;
			}
			return null;
		}
	}

	/** First match wins: the most specific event owns the animation while it is happening. */
	private static final Trigger[] PRIORITY = {
			Trigger.DAMAGE,
			Trigger.LOW_HEALTH,
			Trigger.NEARBY,
			Trigger.SPRINTING,
			Trigger.SNEAKING,
			Trigger.ALWAYS
	};

	/** Pattern order is body order: the ripple travels from the head down. */
	private static final Part[] PATTERN_ORDER = {
			Part.HAT,
			Part.JACKET,
			Part.LEFT_SLEEVE,
			Part.RIGHT_SLEEVE,
			Part.LEFT_PANTS_LEG,
			Part.RIGHT_PANTS_LEG,
			Part.CAPE
	};

	/** Animations the random modes may choose from: the shapes, never themselves. */
	private static final Animation[] SHAPES = {
			Animation.TOGETHER, Animation.CASCADE, Animation.MARQUEE, Animation.ALTERNATE,
			Animation.SPLIT, Animation.GLITCH, Animation.WAVE, Animation.CHECKER,
			Animation.ZIGZAG, Animation.RIPPLE, Animation.STROBE, Animation.GROW
	};

	private static final SkinsPlus INSTANCE = new SkinsPlus();

	private final Random random = new Random();

	/** Where the pattern clock started. Reset when the effect is enabled. */
	private long waveOrigin;

	/** True while the server has a state from us rather than the player's real settings. */
	private boolean pushed;
	/** The customisation bits last sent while {@link #pushed}. */
	private int lastSent = -1;

	private boolean randomShown = true;
	private long randomFlipAt;

	private Animation chaosAnimation = Animation.TOGETHER;
	private long chaosEpoch;
	private long chaosUntil;
	private boolean chaosPaused;

	/** Start of the current burst window; 0 until the next frame after a settings change. */
	private long burstEpoch;

	private SkinsPlus() {
	}

	public static SkinsPlus get() {
		return INSTANCE;
	}

	private static Config config() {
		return Config.get();
	}

	public boolean isEnabled() {
		return config() != null && config().enabled;
	}

	public void setEnabled(boolean enabled) {
		Config config = config();
		if (config == null) return;
		config.enabled = enabled;
		resetSchedules();
		if (enabled) waveOrigin = System.nanoTime();
		config.saveSoon();
	}

	public void toggle() {
		setEnabled(!isEnabled());
	}

	/** Called after a setting edit so a running schedule cannot keep stale timings. */
	public void settingsChanged() {
		resetSchedules();
		config().saveSoon();
	}

	/** A value edit that changes no schedule (sliders, part selection), so timers keep running. */
	public void valuesChanged() {
		config().saveSoon();
	}

	private void resetSchedules() {
		randomFlipAt = 0L;
		randomShown = true;
		chaosUntil = 0L;
		chaosPaused = false;
		chaosEpoch = 0L;
		chaosAnimation = Animation.TOGETHER;
		burstEpoch = 0L;
	}

	public boolean owns(PlayerModelPart part) {
		Part mapped = Part.byModelPart(part);
		return mapped != null && config().parts.contains(mapped.name());
	}

	/** Every part this module is allowed to drive, as a bitmask. */
	public int ownedMask() {
		int mask = 0;
		for (Part part : Part.values()) {
			if (config().parts.contains(part.name())) mask |= part.modelPart.getMask();
		}
		return mask;
	}

	/** The parts that should be visible right now, as a bitmask. */
	public int shownMask() {
		int owned = ownedMask();
		if (!isEnabled() || owned == 0) return owned;
		Trigger trigger = activeTrigger();
		if (trigger == null) return owned;
		return visibleNow(owned, config().animation(trigger), config().speedFor(trigger),
				config().dutyFor(trigger));
	}

	/** The owned parts hidden this frame, i.e. the bits to remove from the server's copy. */
	public int hiddenMask() {
		if (!isEnabled()) return 0;
		return ownedMask() & ~shownMask();
	}

	/** The event whose animation should play, or null when every event is off or none is happening. */
	private Trigger activeTrigger() {
		Config config = config();
		Minecraft minecraft = Minecraft.getInstance();
		Player player = minecraft == null ? null : minecraft.player;
		if (player == null) return null;

		for (Trigger trigger : PRIORITY) {
			Config.EventSettings event = config.event(trigger);
			if (event == null || !event.enabled) continue;
			if (triggerFires(trigger, minecraft, player)) return trigger;
		}
		return null;
	}

	private boolean triggerFires(Trigger trigger, Minecraft minecraft, Player player) {
		Config config = config();
		return switch (trigger) {
			case ALWAYS -> true;
			case DAMAGE -> player.hurtTime > 0;
			case NEARBY -> playerNearby(minecraft, player);
			case LOW_HEALTH -> player.getHealth() <= config.healthThreshold;
			case SPRINTING -> player.isSprinting();
			case SNEAKING -> player.isShiftKeyDown();
		};
	}

	private boolean playerNearby(Minecraft minecraft, Player self) {
		if (minecraft.level == null) return false;
		double radius = config().triggerRadius;
		double squared = radius * radius;
		for (Player other : minecraft.level.players()) {
			if (other == self || other.isSpectator() || other.isInvisible()) continue;
			if (self.distanceToSqr(other) <= squared) return true;
		}
		return false;
	}

	private int visibleNow(int owned, Animation animation, double speed, double duty) {
		Config config = config();
		long origin = waveOrigin;
		long now = System.nanoTime();

		// Bursts gate everything: between them the effect is simply not firing. Each burst
		// restarts its animation, so a short flash is never caught in a hidden phase.
		if (config.bursts) {
			long burstStart = burstStart(now);
			if (burstStart < 0L) return owned;
			if (animation == Animation.RANDOM || animation == Animation.CHAOS) return owned;
			origin = burstStart;
		}

		if (animation == Animation.RANDOM) {
			return randomVisible(duty) ? owned : 0;
		}

		if (origin == 0L) {
			waveOrigin = System.nanoTime();
			origin = waveOrigin;
		}

		Animation shape = animation;
		if (animation == Animation.CHAOS) {
			advanceChaos(System.nanoTime());
			if (chaosPaused) return owned;
			shape = chaosAnimation;
			origin = chaosEpoch;
		} else if (animation == Animation.SHUFFLE) {
			// A fresh shape every shuffleEvery cycles; using the origin as part of the
			// seed also gives each burst its own shape instead of repeating the last one.
			shape = shuffleShape(glitchCycle(origin, speed), origin, config.shuffleEvery);
		}

		double dutyFraction = duty / 100.0;
		double phase = cycleFraction(origin, speed);
		long cycle = glitchCycle(origin, speed);
		int count = 0;
		for (Part part : PATTERN_ORDER) {
			if (config.parts.contains(part.name())) count++;
		}

		int mask = 0;
		int index = 0;
		for (Part part : PATTERN_ORDER) {
			if (!config.parts.contains(part.name())) continue;
			if (partVisible(index, count, phase, dutyFraction, shape, cycle)) mask |= part.modelPart.getMask();
			index++;
		}
		return mask;
	}

	/** The shape Random cycle shows after {@code cycles} cycles, seeded so each burst differs. */
	static Animation shuffleShape(long cycles, long seed, int every) {
		long block = Math.floorDiv(cycles, Math.max(1, every));
		return SHAPES[(int) Math.floorMod(mix(block + seed), (long) SHAPES.length)];
	}

	/** Whether part {@code index} of {@code count} is visible at this point in the cycle. */
	private boolean partVisible(int index, int count, double phase, double dutyFraction, Animation animation,
			long cycle) {
		return switch (animation) {
			case CASCADE -> {
				double step = dutyFraction / Math.max(1, count);
				yield fraction(phase - index * step) < dutyFraction;
			}
			case MARQUEE -> {
				double step = 1.0 / Math.max(1, count);
				yield fraction(phase - index * step) < dutyFraction;
			}
			case ALTERNATE -> (phase < dutyFraction) == (index % 2 == 0);
			case SPLIT -> (phase < dutyFraction) == (index < (count + 1) / 2);
			case GLITCH -> (phase < dutyFraction) == glitchSet(cycle, index, count, dutyFraction);
			case WAVE -> {
				double threshold = 2.0 * dutyFraction - 1.0;
				yield Math.sin((phase + index * 0.25) * Math.PI * 2.0) < threshold;
			}
			case CHECKER -> (phase < dutyFraction) == ((index / 2) % 2 == 0);
			case ZIGZAG -> fraction(phase * 2.0 + (index % 2) * 0.5) < dutyFraction;
			case RIPPLE -> {
				double centre = (count - 1) / 2.0;
				double spread = Math.max(1.0, (count - 1) / 2.0);
				double distance = Math.abs(index - centre) / spread;
				yield fraction(phase * 2.0 - distance) < dutyFraction;
			}
			case STROBE -> {
				double pulse = Math.max(0.02, dutyFraction * 0.5);
				yield phase < pulse || (phase >= 0.5 && phase < 0.5 + pulse);
			}
			case GROW -> {
				double t = fraction(phase);
				if (t < 0.5) {
					yield index < (int) Math.ceil(t * 2.0 * count);
				}
				int visible = (int) Math.ceil((1.0 - t) * 2.0 * count);
				yield index >= count - visible;
			}
			default -> phase < dutyFraction;
		};
	}

	/** A deterministic pseudo-random subset: the same cycle always picks the same parts. */
	private boolean glitchSet(long cycle, int index, int count, double dutyFraction) {
		int wanted = Math.max(1, Math.min(count - 1, (int) Math.round(count * dutyFraction)));
		long hash = mix(cycle * 0x9E3779B97F4A7C15L + index);
		long threshold = (long) ((double) wanted / count * Long.MAX_VALUE);
		return (hash & Long.MAX_VALUE) < threshold;
	}

	private static long mix(long value) {
		value ^= value >>> 33;
		value *= 0xff51afd7ed558ccdL;
		value ^= value >>> 33;
		value *= 0xc4ceb9fe1a85ec53L;
		value ^= value >>> 33;
		return value;
	}

	private static double fraction(double value) {
		double part = value - Math.floor(value);
		return part < 0 ? part + 1.0 : part;
	}

	/** How far through the current cycle we are, counting cycles rather than fractions. */
	private double cycleIndex(long origin, double speed) {
		if (speed <= 0.0) return 0.0;
		return (System.nanoTime() - origin) / 1.0e9 * speed;
	}

	private double cycleFraction(long origin, double speed) {
		return fraction(cycleIndex(origin, speed));
	}

	/** The glitch cycle number, derived the same way as the phase. */
	private long glitchCycle(long origin, double speed) {
		return (long) Math.floor(cycleIndex(origin, speed));
	}

	/**
	 * When the current flash started, or -1 outside one: {@code burstCount} random moments inside
	 * every {@code burstWindow}, each lasting {@code burstLength}. The schedule is derived from the
	 * clock and a hash, so it is stable across frames without any bookkeeping.
	 */
	private long burstStart(long now) {
		Config config = config();
		long windowNanos = Math.max(1_000_000_000L, (long) (config.burstWindow * 1.0e9));
		long lengthNanos = Math.max(50_000_000L, Math.min(windowNanos, (long) (config.burstLength * 1.0e9)));
		long origin = burstEpoch;
		if (origin == 0L) {
			burstEpoch = now;
			origin = now;
		}
		long elapsed = Math.max(0L, now - origin);
		long windowIndex = elapsed / windowNanos;
		long windowStart = origin + windowIndex * windowNanos;
		long maxOffset = Math.max(0L, windowNanos - lengthNanos);
		int count = Math.max(1, Math.min(30, config.burstCount));
		long started = -1L;
		for (int i = 0; i < count; i++) {
			long at = windowStart + (long) (burstFraction(windowIndex, i) * maxOffset);
			if (now >= at && now < at + lengthNanos) started = Math.max(started, at);
		}
		return started;
	}

	/** A stable pseudo-random fraction for one burst inside one window. */
	private static double burstFraction(long window, int index) {
		long hash = mix(window * 0x9E3779B97F4A7C15L + index * 0xBF58476D1CE4E5B9L + 0x94D049BB133111EBL);
		return (hash >>> 11) * 0x1.0p-53;
	}

	/** Random animation's square wave: each state lasts a fresh, randomly chosen interval. */
	private boolean randomVisible(double duty) {
		long now = System.nanoTime();
		if (randomFlipAt == 0L) {
			randomShown = true;
			randomFlipAt = now + holdNanos(true, duty);
		}
		while (now >= randomFlipAt) {
			randomShown = !randomShown;
			randomFlipAt += holdNanos(randomShown, duty);
		}
		return randomShown;
	}

	/** Random pattern's schedule: a random shape, then a rest, then another shape. */
	private void advanceChaos(long now) {
		if (chaosUntil == 0L) {
			startChaosRun(now);
			return;
		}
		while (now >= chaosUntil) {
			if (chaosPaused) startChaosRun(chaosUntil);
			else startChaosRest(chaosUntil);
		}
	}

	private void startChaosRun(long at) {
		Animation next = chaosAnimation;
		for (int attempts = 0; next == chaosAnimation && attempts < 8; attempts++) {
			next = SHAPES[random.nextInt(SHAPES.length)];
		}
		chaosAnimation = next;
		chaosPaused = false;
		chaosEpoch = at;
		chaosUntil = at + seconds(chaosRunSeconds());
	}

	private void startChaosRest(long at) {
		chaosPaused = true;
		chaosUntil = at + seconds(config().chaosPause);
	}

	private double chaosRunSeconds() {
		double low = Math.min(config().chaosRunMin, config().chaosRunMax);
		double high = Math.max(config().chaosRunMin, config().chaosRunMax);
		return low + random.nextDouble() * (high - low);
	}

	private static long seconds(double value) {
		return Math.max(0L, (long) (value * 1.0e9));
	}

	/** How long the current random-animation state lasts, in nanoseconds. */
	private long holdNanos(boolean visible, double duty) {
		Config config = config();
		double low = Math.min(config.intervalMin, config.intervalMax);
		double high = Math.max(config.intervalMin, config.intervalMax);
		double rate = Math.max(0.05, low + random.nextDouble() * (high - low));
		double dutyFraction = duty / 100.0;
		double seconds = (visible ? dutyFraction * 2.0 : (1.0 - dutyFraction) * 2.0) / rate;
		return Math.max(1_000_000L, (long) (seconds * 1.0e9));
	}

	/** Called every client tick: keeps the server's copy of the model in step when asked to. */
	public void tick(Minecraft minecraft) {
		if (minecraft == null || minecraft.player == null || minecraft.level == null) {
			pushed = false;
			lastSent = -1;
			randomFlipAt = 0L;
			chaosUntil = 0L;
			return;
		}

		Config config = config();
		if (!config.enabled || !config.visibleToOthers) {
			restoreIfPushed(minecraft);
			return;
		}

		int hidden = hiddenMask();
		if (hidden == 0) {
			restoreIfPushed(minecraft);
			return;
		}

		ClientPacketListener connection = minecraft.getConnection();
		if (connection == null) return;

		ClientInformation real = minecraft.options.buildPlayerInformation();
		int customisation = real.modelCustomisation() & ~hidden;
		if (pushed && customisation == lastSent) return;

		connection.broadcastClientInformation(withCustomisation(real, customisation));
		pushed = true;
		lastSent = customisation;
	}

	private void restoreIfPushed(Minecraft minecraft) {
		if (!pushed) return;
		pushed = false;
		lastSent = -1;
		ClientPacketListener connection = minecraft.getConnection();
		if (connection == null) return;
		connection.broadcastClientInformation(minecraft.options.buildPlayerInformation());
	}

	private static ClientInformation withCustomisation(ClientInformation real, int customisation) {
		return new ClientInformation(real.language(), real.viewDistance(), real.chatVisibility(),
				real.chatColors(), customisation, real.mainHand(), real.textFilteringEnabled(),
				real.allowsListing(), real.particleStatus());
	}
}
